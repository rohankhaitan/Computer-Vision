import os


def get_dir_path():
	return os.path.dirname(os.path.dirname(os.path.realpath(__file__))).replace('\\', '/')


def does_dir_exist(path):
	return os.path.exists(path)


def create_dir(path):
	if not os.path.exists(path):
		os.makedirs(path)
