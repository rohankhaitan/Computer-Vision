from components import BaseComponent
import logging
from datetime import datetime
from utilities.utilities import create_dir
from common.error import *
from ml_io import IOClass


class Pipeline:
	def __init__(self, pipeline_name, components, root_path):
		self.pipeline_name = pipeline_name
		self.logs_path = None
		self.root_path = "{}/{}".format(root_path, self.pipeline_name)
		self.ioHandle = IOClass(self.root_path)
		create_dir(self.root_path)
		create_dir(self.root_path + '/logs')
		self.add_file_logger()
		self.add_components(components)

	def add_file_logger(self):
		log_filename = "{}/logs/log_{}.log".format(self.root_path, datetime.now().strftime('%d_%m_%Y'))
		format = logging.Formatter(fmt='%(asctime)s [%(levelname)s] %(message)s', datefmt='%H:%M:%S')

		c_handler = logging.StreamHandler()
		c_handler.setLevel(logging.DEBUG)
		c_handler.setFormatter(format)

		logging.basicConfig(
			filename=log_filename,
			filemode='a+',
			format='%(asctime)s [%(levelname)s]%(message)s',
			datefmt='%H:%M:%S',
			level=logging.DEBUG)
		logging.getLogger().addHandler(c_handler)

	def add_components(self, components_list: BaseComponent):
		self.components = components_list
		for component in self.components:
			component.setup_component(self.ioHandle)

	def run(self):
		success_run = []
		for component in self.components:
			ret = component.run_component()
			if ret != RC_OK:
				return ret
			success_run.append(component.component_name)
		return RC_OK
