from Pipeline.Pipeline import Pipeline
from components.DataIngestion import DataIngestion
from components.DataValidation import DataValidation
from components.FeatureEngineering import FeatureEngineering
from components.Trainer import Trainer
import logging


def ingestion_run_fn(inputs, **kwargs):
	list1 = [1]
	dict1 = {
		"ingestion": "ok"
	}
	return {
		"list1": list1,
		"dict1": dict1
	}


def validation_run_fn(inputs, **kwargs):
	logging.info(inputs)
	list2 = [2]
	dict2 = {
		"validation": "ok"
	}

	return {
		"list2": list2,
		"dict2": dict2
	}


def eng_run_fn(inputs, **kwargs):
	logging.info(inputs)
	list3 = [3]
	dict3 = {
		"eng": "ok"
	}
	return {
		"list3": list3,
		"dict3": dict3
	}


def trainer_run_fn(inputs, **kwargs):
	logging.info(inputs)
	list4 = [4]
	dict4 = {
		"train": "ok"
	}
	return {
		"list4": list4,
		"dict4": dict4
	}


if __name__ == '__main__':
	metadata = {
		"metadata": 1
	}
	hyper_params = {
		"nLayers": 2,
		"framework": "pytorch"
	}

	ingestor = DataIngestion([], ['list1', 'dict1'], ingestion_run_fn, metadata)
	validator = DataValidation(ingestor.outputs(['list1']), ['list2', 'dict2'], validation_run_fn, None, None)
	# validator = DataValidation(get_component_artifacts(DataIngestion, ['list1']), ['list2'], validation_run_fn, None, None)
	feng = FeatureEngineering(validator.outputs(['list2', 'dict2']), ['list3', 'dict3'], eng_run_fn, None, None)
	trainer = Trainer(feng.outputs(['list3', 'dict3']), ['list4', 'dict4'], trainer_run_fn, hyper_params)

	component_list = [ingestor, validator, feng, trainer]

	pipeline_name = "pipeline1"
	pipeline = Pipeline('Pipeline1', component_list, "../pipeline_data_path")
	pipeline.run()


def trainer_run_fn(input_path, output_path, hyper_params):
	print("Running training function")
