
def trainer_run_fn(input_path, output_path,hyper_params,training_args):
    print("Running training function")