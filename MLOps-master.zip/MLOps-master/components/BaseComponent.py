from abc import ABC, abstractmethod
import pkg_resources
import logging
import json
from common.error import *
import pickle


class BaseComponent(ABC):
	def __init__(self, exp_inputs, exp_outputs, run_fn, track_gpu_usage=False, **kwargs):
		"""
		:param run_fn:
		:param kwargs:
		"""
		self.component_name = self.__class__.__name__
		self.component_path = None
		self.artifacts_path = None
		self.metadata_path = None

		self.exp_inputs = exp_inputs
		self.exp_outputs = exp_outputs
		self.run_fn = run_fn
		self.kwargs = kwargs

		if track_gpu_usage:
			self.track_gpu_usage()

		self.setup_output_paths()
		self.ioHandle = None

	# TODO: implement function
	def track_gpu_usage(self):
		print("HereQQ")
		pass

	# def set_component_name(self):

	def setup_output_paths(self):
		self.component_path = self.component_name
		self.artifacts_path = "{}/artifacts".format(self.component_path)
		self.metadata_path = "{}/metadata".format(self.component_path)

	def create_directories(self):
		# Creating new directories
		self.ioHandle.create_dir(self.artifacts_path)
		self.ioHandle.create_dir(self.metadata_path)

	def check_input_paths(self):
		# if does_dir_exist(self.)
		# 	pass
		pass

	def store_metadata(self):
		"""
		stores metadata to metadata/meta.data
		:return:
		"""
		self.ioHandle.write_output(
			"{}/{}".format(self.metadata_path, "meta.data"), json.dumps(self.kwargs).encode())

	def store_environment(self):
		"""
		stores installed packages to metadata/env.data
		:return:
		"""
		installed_packages = pkg_resources.working_set
		installed_packages_list = sorted(
			["%s==%s" % (i.key, i.version) for i in installed_packages]
		)
		logging.info("Installed Pakages: {}".format(installed_packages_list))
		self.ioHandle.write_output(
			"{}/{}".format(self.metadata_path, "env.data"), json.dumps(installed_packages_list, indent=4).encode())

	def setup_component(self, ioHandle):
		self.ioHandle = ioHandle
		logging.info("Starting component {}...".format(self.component_name))
		self.create_directories()
		logging.info("checking input paths")
		self.check_input_paths()
		self.store_environment()
		self.store_metadata()

	def _run_component(self, run_fn):
		try:
			inps = self.get_outputs(self.exp_inputs)
		except Exception as e:
			logging.info("Incorrect inputs in {}".format(self.component_path))
			return RC_INCORRECT_OUTPUTS
		outputs = run_fn(inps, **self.kwargs)

		for val in self.exp_outputs:
			if val not in outputs:
				return RC_INCORRECT_OUTPUTS

		for key, val in outputs.items():
			self.ioHandle.write_output("{}/{}".format(self.artifacts_path, key), pickle.dumps(val))
		return RC_OK

	@abstractmethod
	def run_component(self):
		"""
		:return: list
		"""
		pass

	def outputs(self, outputs):
		return ["{}/{}".format(self.artifacts_path, out) for out in outputs]

	def get_outputs(self, outputs):
		outs = []
		for out_file in outputs:
			outs.append(pickle.loads(self.ioHandle.read(out_file)))
		return outs

	# TODO: not sure if needed
	def exit_component(self):
		self.store_environment()


# TODO: load artifact and store artifacts


if __name__ == "__main__":
	pass
