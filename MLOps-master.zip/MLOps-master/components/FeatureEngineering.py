from components.BaseComponent import BaseComponent
import pickle
from common.error import *
import logging


class FeatureEngineering(BaseComponent):
	def __init__(self, exp_inputs, exp_outputs, run_fn, metadata, track_gpu_usage=False, **kwargs):
		super().__init__(exp_inputs, exp_outputs, run_fn, track_gpu_usage, metadata=metadata, **kwargs)

		self.metadata = metadata
		self.kwargs = kwargs

	def run_component(self):
		logging.info("Running feature engineering")
		return self._run_component(self.run_fn)


if __name__ == '__main__':
	pass
