from ml_io.MLIO import MLIO


class DISKIO(MLIO):
	def __init__(self, path):
		super().__init__(path)

	def read(self, filename):
		with open("{}/{}".format(self.root_path, filename), 'rb') as f:
			return f.read()

	def write_output(self, filename, data):
		with open("{}/{}".format(self.root_path, filename), 'wb') as f:
			f.write(data)


if __name__ == "__main__":
	ob = DISKIO("../logs/artifacts")
