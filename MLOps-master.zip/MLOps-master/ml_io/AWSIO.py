from ml_io.MLIO import MLIO


class AWSIO(MLIO):

    def __init__(self, path):
        super().__init__(path)

    def read(self):
        print("Reading form AWS")

    def write_output(self, filename, data):
        with open("{}/{}".format(self.path, filename), 'wb') as f:
            f.write(data)

if __name__ == "__main__":
    ob = AWSIO("../logs/artifacts")
    ob.read()
