from ml_io import AWSIO
from ml_io import DiskIO
from cofig import config

conf = config.IOClass
if conf == "AWSIO":
    IOClass = AWSIO.AWSIO
else:
    IOClass = DiskIO.DISKIO
