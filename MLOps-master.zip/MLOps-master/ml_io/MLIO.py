from abc import ABC, abstractmethod
from utilities.utilities import create_dir


class MLIO(ABC):
	def __init__(self, path):
		self.root_path = path

	@abstractmethod
	def read(self, filename):
		# TODO: append path to root path
		pass

	@abstractmethod
	def write_output(self, filename, data):
		# TODO: append path to root path
		pass

	def create_dir(self, path):
		create_dir(self.root_path + '/' + path)


if __name__ == '__main__':
	pass
