# ML Ops

## About
The project specifies a generic structure that modularizes the entire Machine Learning pipeline into separate manageabel components.



## Structure
The whole project is divided into stateless components that can be run independently.


### Components

##### Base Component


Gives the basic interface for all the modules that is inherited by all the components.
```python
class BaseComponent:
    def __init__(self, input_path, output_path, run_fn, metadata, component_args):
        """
        :param input_path: 
        :param output_path: 
        :param run_fn: 
        :param metadata: 
        :param kwargs: 
        """
        pass

```


##### DataIngestion Component

##### DataValidation Component

##### FeatureEngineering Component

##### Trainer Component


### Pipeline


### Features
- Stateless
- Scalable
- Different components can run on different clusters
